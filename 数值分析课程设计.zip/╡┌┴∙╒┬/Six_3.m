%�����µ�3��
%���ھ���Runge-Kutta����(RK4)
%���ߣ�������

clear;
clc;

Epsilon = 0.5*10^-10; %�ؼ�������ޡ�

%--------------------Ԥ�����һ�ֻ��ֵĽ�--------------------%
js =1; %������
L = 5;
m = 2^L;
h = 1/m;

y0 = 1;
for i = 0 : m-1
    if (i==0)
        yi1 = y0;
    else
        yi1 = y(js,i);
    end
    xi1 = i * h;
    K1 = cos(xi1^2+yi1^2) / (xi1^4+yi1^4);
    
    xi2 = xi1 + h/2;
    yi2 = yi1 + h/2 * K1;
    K2 = cos(xi2^2+yi2^2) / (xi2^4+yi2^4);
    
    xi3 = xi1 + h/2;
    yi3 = yi1 + h/2 * K2;
    K3 = cos(xi3^2+yi3^2) / (xi3^4+yi3^4);
    
    xi4 = xi1 + h;
    yi4 = yi1 + h * K3;
    K4 = cos(xi4^2+yi4^2) / (xi4^4+yi4^4);
    
    y(js,i+1) = yi1 + h/6 * (K1 + 2*K2 + 2*K3 + K4);
end

%--------------------ѭ�����������--------------------%
while (1)
    %--------------------�����һ���--------------------%
    js = js+1;
    L = L+1;
    m = 2^L;
    h = 1/m;
    for i = 0 : m-1
        if (i==0)
            yi1 = y0;
        else
            yi1 = y(js,i);
        end
        xi1 = i * h;
        K1 = cos(xi1^2+yi1^2) / (xi1^4+yi1^4);
        
        xi2 = xi1 + h/2;
        yi2 = yi1 + h/2 * K1;
        K2 = cos(xi2^2+yi2^2) / (xi2^4+yi2^4);
        
        xi3 = xi1 + h/2;
        yi3 = yi1 + h/2 * K2;
        K3 = cos(xi3^2+yi3^2) / (xi3^4+yi3^4);
        
        xi4 = xi1 + h;
        yi4 = yi1 + h * K3;
        K4 = cos(xi4^2+yi4^2) / (xi4^4+yi4^4);
        
        y(js,i+1) = yi1 + h/6 * (K1 + 2*K2 + 2*K3 + K4);
    end
    %--------------------����E(m)--------------------%
    MAX = 0;
    for i = 1 : m/2
        if abs(y(js,i*2)-y(js-1,i)) > MAX
            MAX = abs(y(js,i*2)-y(js-1,i));
        end
    end
    E(L-1) = MAX;
    if MAX <= Epsilon
        break;
    end
end

